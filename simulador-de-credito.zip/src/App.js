import './App.css';
import Card from './components/Card';

function App() {

  return (
    <div className="App on-dark">
      <Card />
    </div>
  );
}

export default App;
